# Project Showcase License

This project is a showcase of my abilities in Android development. All code within this project is self-constructed and intended solely for demonstration purposes. By accessing or using this project, you agree to the following terms:

1. **No Use or Reuse**: You may not use, download, or copy any part of this code for any purpose other than viewing it as a demonstration of my skills.

2. **No Redistribution**: You may not distribute this code to others or make it publicly available.

3. **No Modification**: You may not modify or adapt this code for any purpose.

4. **No Commercial Use**: This code may not be used for commercial purposes.

5. **Attribution**: If you reference or showcase this project, please provide appropriate attribution to the original author (Me:Vedant.R.J.Chourey).

## Disclaimer

This project is not intended for production use, and the author assumes no liability for any consequences resulting from its use.

---

**Note**: All Rights for this ***Project*** are 'Reserved' to the owner of this ***Repository***
